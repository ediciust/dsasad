const chalk = require('chalk');
const moment = require('moment');
const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');

var prefix = ayarlar.prefix;

module.exports = client => {
 setInterval(function() {
    setTimeout(() => {  
client.channels.get("536598954977132544").setName(`Toplam Kanal: ${client.channels.size}`)  
    }, 1000);

}, 8000);
client.user.setPresence({
        game: {
name: `Hayatinla`,
            type: 'PLAYING'
        },
        status: 'dnd'
    })

    console.log(`Giri� Yap�ld�!`);
  console.log(client.channels.size + ` Kanal - ` + client.guilds.size + ` Sunucu - ` + client.guilds.reduce((a, b) => a + b.memberCount, 0).toLocaleString() + ` Kullan�c�`); 
}